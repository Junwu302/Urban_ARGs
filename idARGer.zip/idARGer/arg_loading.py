import re
import os
import sys
import numpy as np
import fasttext
from Bio import SeqIO
from tqdm import tqdm
import tensorflow as tf
import keras.backend as K
from keras.preprocessing.sequence import pad_sequences
from keras.utils import normalize


def fasta2head(inputfile, outdir, kmer, prefix):

    fo = open(outdir + prefix + '.headers', 'w')

    for record in SeqIO.parse(inputfile, 'fasta'):
        genome = str(record.seq).upper()
        sentences = re.findall('.' * kmer, genome)
        fo.write(record.description + "\t" + str(len(sentences)) + '\n')

    return fo.name


def fasta2vec(inputfile, wordvec_model, outdir, kmer, list_dia, prefix):

    fo1 = open(outdir + prefix + '.headers', 'w')
    fo2 = open(outdir + prefix + '.sentences', 'w')

    for record in SeqIO.parse(inputfile, 'fasta'):
        genome = str(record.seq).upper()
        sentences = re.findall('.' * kmer, genome)
        if record.description not in list_dia:
            fo1.write(record.description + "\t" + str(len(sentences)) + '\n')
            fo2.write(" ".join(sentences) + '\n')
    fo1.close()
    fo2.close()

    model = fasttext.load_model(wordvec_model)
    with open(outdir + prefix + '.sentences') as f:
        f1 = open(outdir + prefix + '.sentences.wv', 'w')
        for i in f:
            f1.write(str(model[i]) + '\n')
        f1.close()

    return fo1.name, fo2.name, f1.name



IUPAC_CODES = {'A': 0.984, 'C': 0.906, 'E': 1.094, 'D': 1.068, 'G': 1.031, 'F': 0.915, 'I': 0.927, 'H': 0.950,
               'K': 1.102, 'M': 0.952, 'L': 0.935, 'N': 1.048, 'Q': 1.037, 'P': 1.049, 'S': 1.046, 'R': 1.008,
               'T': 0.997, 'W': 0.904, 'V': 0.931, 'Y': 0.929, '*': 0}


def aa2int(i):
    try:
        return IUPAC_CODES[i]
    except Exception as e:
        return IUPAC_CODES['*']


def get_headers(labels_file=''):
    categories = {}
    category_index = 0
    index_start = []

    for i in open(labels_file):
        i = i.strip().split('\t')
        index_start.append(int(i[1]))
        arg_classes = i[0]

        for arg_class in arg_classes.split("'")[1::2]:
            try:
                assert (categories[arg_class])
            except Exception as e:
                categories[arg_class] = category_index
                category_index += 1
    categories = {i: ix for ix, i in enumerate(categories)}

    return [categories, index_start]


def get_labels(classes={}, labels_file=''):
    total_categories = len(classes)
    category_labels = []

    for i in open(labels_file):
        i = i.strip().split('\t')
        arg_classes = i[0]
        category_label = np.zeros(total_categories)
        for arg_class in arg_classes.split("'")[1::2]:
            category_label[classes[arg_class]] = 1
        category_labels.append(category_label)

    return np.array(category_labels)


def get_wordvectors(dataset_file="", sequence_file="", maxlen=1200):
    dataset = []
    sequences = []
    lengths = []

    for ix, i in tqdm(enumerate(open(dataset_file))):
        i = i.split()
        l = []
        for k in i:
            k = re.findall('(-?[\d.\d]+)', k)[0]
            l.append(k)
        item = np.array([float(str(t)) for t in l])
        dataset.append(item)
        lengths.append(len(item))

    for i in tqdm(open(sequence_file)):
        item = [[aa2int(k)] for k in i]
        sequences.append(item)
    sequences = pad_sequences(sequences, maxlen=maxlen, padding="post", dtype="float32", truncating="post")
    dataset = np.array(dataset)
    sequences = np.array(sequences)

    return normalize(dataset, axis=-1, order=2), sequences


def recall(y_true, y_pred):
    c1 = K.sum(K.round(K.clip(y_true * y_pred, 0, 1)))
    c3 = K.sum(K.round(K.clip(y_true, 0, 1)))
    if c3 == 0:
        return 0
    recall = c1 / (c3 + K.epsilon())
    return recall


def auc(y_true, y_pred):

    def binary_PFA(y_true, y_pred, threshold=K.variable(value=0.5)):
        y_pred = K.cast(y_pred >= threshold, 'float32')
        N = K.sum(1 - y_true)
        FP = K.sum(y_pred - y_pred * y_true)
        return FP / N

    def binary_PTA(y_true, y_pred, threshold=K.variable(value=0.5)):
        y_pred = K.cast(y_pred >= threshold, 'float32')
        P = K.sum(y_true)
        TP = K.sum(y_pred * y_true)
        return TP / P

    ptas = tf.stack([binary_PTA(y_true, y_pred, k) for k in np.linspace(0, 1, 1000)], axis=0)
    pfas = tf.stack([binary_PFA(y_true, y_pred, k) for k in np.linspace(0, 1, 1000)], axis=0)
    pfas = tf.concat([tf.ones((1,)), pfas], axis=0)
    binSizes = -(pfas[1:] - pfas[:-1])
    s = ptas * binSizes
    return K.sum(s, axis=0)