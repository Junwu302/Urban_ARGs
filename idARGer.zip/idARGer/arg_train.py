import numpy as np
import tensorflow as tf
import re
from time import time

import sys
import os

import keras
from keras.models import Model
import keras.backend as K
from keras.callbacks import TensorBoard
from keras.preprocessing.sequence import pad_sequences
from keras.optimizers import adam
from keras.layers import Dense, Dropout, Activation, Input, Lambda
from keras.layers import concatenate, add, multiply, average, maximum, Flatten
from keras.layers import Conv1D, CuDNNLSTM, LSTM, Bidirectional, BatchNormalization, MaxPooling1D, AveragePooling1D
from keras.initializers import glorot_uniform, he_uniform, orthogonal
from keras.utils import plot_model, normalize
from keras.callbacks import ModelCheckpoint, TensorBoard

from arg_loading import fasta2head, fasta2vec, get_headers, get_labels, get_wordvectors, recall, auc

import errno
import warnings
from contextlib import redirect_stdout

class NetConfig:

    """
    NetWork configuration class.

    """

    def __init__(self, config):
        """NetConfig constructor"""
        # Devices Config #
        # Get the number of available GPUs
        self.n_gpus = config['Devices'].getint('N_GPUs')

        # Input Data Config #
        # Set the sequence length and the alphabet
        self.kmer = config['InputData'].getint('Kmer')
        self.seq_length = config['InputData'].getint('SeqLength')
        self.seq_dim = config['InputData'].getint('SeqDim')
        self.wv_dim = config['InputData'].getint('WVDim')

        # Architecture Config #
        # Define the network architecture
        self.n_conv = config['Architecture'].getint('N_Conv')
        self.conv_units = [int(u) for u in config['Architecture']['Conv_Units'].split(',')]
        self.conv_filter_size = [int(s) for s in config['Architecture']['Conv_FilterSize'].split(',')]
        self.conv_bn = [bool(b) for b in config['Architecture']['Conv_BN'].split(',')]
        self.conv_pooling = [str(p) for p in config['Architecture']['Conv_Pooling'].split(',')]
        self.recurrent_units = config['Architecture'].getint('Recurrent_Units')
        self.recurrent_dropout = config['Architecture'].getfloat('Recurrent_Dropout')

        # Paths Config #
        # Set the input data paths

        self.header_path = config['Paths']['HeaderData']
        self.train_path = config['Paths']['TrainingPath']
        self.test_path = config['Paths']['TestingPath']
        self.wv_model_path = config['Paths']['WVPath']
        self.out_path = config['Paths']['OutPath']
        self.runname = config['Paths']['RunName']

        # Training Config #
        # Set the number op epochs, batch size and the optimizer
        self.epoch = config['Training'].getint('Epoch')
        self.batch_size = config['Training'].getint('BatchSize')
        self.learning_rate = config['Training'].getfloat('LearningRate')
        self.decay = config['Training'].getfloat('Decay')
        self.optimization_method = config['Training']['Optimizer']
        if self.optimization_method == "adam":
            self.optimizer = adam(lr=self.learning_rate, decay=self.decay)
        else:
            warnings.warn("Custom learning rates implemented for Adam only. Using default Keras learning rate.")
            self.optimizer = self.optimization_method
        # If needed, log the memory usage
        self.summaries = config['Training'].getboolean('Summaries')
        self.log_superpath = self.out_path
        self.log_dir = self.log_superpath + "/{runname}-logs".format(runname=self.runname)



class DeepNet:

    """
    neural network class.

    """

    def __init__(self, config):
        self.config = config
        self.history = None
        self.header = None
        self.y_train_path = None
        self.seq_train_path = None
        self.wv_train_path = None
        self.y_test_path = None
        self.seq_test_path = None
        self.wv_test_path = None
        self.classes = {}
        self.index = {}
        self.x_train_wordvectors = None
        self.x_train_numerical = None
        self.y_train = None
        self.outdim = 0
        self.wv_length = 512
        self.x_test_wordvectors = None
        self.x_test_numerical = None
        self.y_test = None
        self.model = None
        self.reverse_classes_dict = {}

        try:
            os.makedirs(self.config.log_dir)
        except OSError as e:
            if e.errno != errno.EEXIST:
                raise

        self.__set_callbacks()



    def load_data(self):
        print("Loading...")

        self.header = fasta2head(
            inputfile=self.config.header_path,
            outdir=self.config.out_path,
            kmer=self.config.kmer,
            prefix=self.config.runname+'_head'
        )

        self.y_train_path, self.seq_train_path, self.wv_train_path = fasta2vec(
            inputfile=self.config.train_path,
            wordvec_model=self.config.wv_model_path,
            outdir=self.config.out_path,
            kmer=self.config.kmer,
            list_dia=[],
            prefix=self.config.runname+'_train'
        )

        self.y_test_path, self.seq_test_path, self.wv_test_path = fasta2vec(
            inputfile=self.config.test_path,
            wordvec_model=self.config.wv_model_path,
            outdir=self.config.out_path,
            kmer=self.config.kmer,
            list_dia=[],
            prefix=self.config.runname+'_test'
        )

        self.classes, self.index = get_headers(self.header)

        self.y_train = get_labels(classes=self.classes, labels_file=self.y_train_path)

        self.y_test = get_labels(classes=self.classes, labels_file=self.y_test_path)

        self.x_train_wordvectors, self.x_train_numerical = get_wordvectors(
            dataset_file=self.wv_train_path,
            sequence_file=self.seq_train_path,
            maxlen=self.config.seq_length
        )

        self.reverse_classes_dict = {int(self.classes[i]): i for i in self.classes}
        self.wv_length = self.x_train_wordvectors.shape[1]
        self.outdim = len(self.classes)

        self.x_test_wordvectors, self.x_test_numerical = get_wordvectors(
            dataset_file=self.wv_test_path,
            sequence_file=self.seq_test_path,
            maxlen=self.config.seq_length
        )


    def __add_lstm(self, w):
        # LSTM with sigmoid activation corresponds to the CuDNNLSTM
        if self.config.n_gpus > 0:
            w = keras.layers.Bidirectional(keras.layers.CuDNNLSTM(self.config.recurrent_units,
                                                             return_sequences=True,
                                                             dropout=0.2,
                                                             recurrent_dropout=self.config.recurrent_dropout),
                                           merge_mode='concat',weights=None)(w)
        else:
            w = keras.layers.Bidirectional(keras.layers.LSTM(self.config.recurrent_units,
                                                             return_sequences=True,
                                                             dropout=0.2,
                                                             recurrent_dropout=self.config.recurrent_dropout),
                                           merge_mode='concat',weights=None)(w)
        return w


    def build_model(self):
        print("Building model...")
        # Number of added recurrent layers
        self.__current_recurrent = 0
        # Initialize input
        input_c = keras.Input(shape=(self.config.seq_length, self.config.seq_dim), name='input_c')
        input_w = keras.Input(shape=(self.wv_length,), name='input_w')
        x = input_c
        w = input_w
        # For convolutional layers
        for i in range(0, self.config.n_conv):
            # Add layer
            # Standard convolutional layer
            x = keras.layers.Conv1D(
                self.config.conv_units[i], self.config.conv_filter_size[i],
                input_shape=(self.config.seq_length, self.config.seq_dim),
                activation='elu',
                padding='same',
                kernel_initializer='he_uniform')(x)            # Add batch norm
            if self.config.conv_bn[i]:
                # Standard batch normalization layer
                x = keras.layers.BatchNormalization()(x)
            # Add pooling first
            if self.config.conv_pooling[i] == 'max':
                x = MaxPooling1D()(x)
            elif self.config.conv_pooling[i] == 'average':
                x = AveragePooling1D()(x)
            elif not (self.config.conv_pooling[i] in ['none']):
                # Skip pooling if it should be applied to the last conv layer or skipped altogether.
                # Throw a ValueError if the pooling method is unrecognized.
                raise ValueError('Unknown pooling method')
        x = keras.layers.Flatten()(x)

        # Recurrent layers
        # Add a bidirectional recurrent layer. CuDNNLSTM requires a GPU and tensorflow with cuDNN
        w = keras.layers.embeddings.Embedding(input_dim=self.wv_length + 1,
                                              mask_zero=False,
                                              output_dim=self.config.wv_dim)(w)
        w = self.__add_lstm(w)
        w = keras.layers.pooling.MaxPooling1D()(w)
        w = keras.layers.wrappers.TimeDistributed(keras.layers.Dense(64))(w)
        w = keras.layers.Flatten()(w)


        # Merge layers
        m = keras.layers.concatenate([w, x])

        # Output layer for binary classification
        m = keras.layers.Dense(100, activation='relu')(m)
        outputs = keras.layers.Dense(self.outdim, activation="sigmoid", name="outputs")(m)

        # Initialize the model
        self.model = keras.models.Model(inputs=[input_c, input_w], outputs=[outputs])


    def compile_model(self):
        print("Compiling...")
        self.model.compile(optimizer=self.config.optimizer,
                           loss={'outputs': 'binary_crossentropy'},
                           loss_weights={'outputs': 1.0},
                           metrics=['accuracy', recall, auc])

        # Print summary and plot model
        if self.config.summaries:
            with open(self.config.log_dir + "/summary-{runname}.txt".format(runname=self.config.runname), 'w') as f:
                with redirect_stdout(f):
                    self.model.summary()


    def __set_callbacks(self):
        self.callbacks = []


        # Save model after every epoch
        checkpoint_name = self.config.log_dir + "/nn-{runname}-".format(runname=self.config.runname)
        self.callbacks.append(ModelCheckpoint(filepath=checkpoint_name + "e{epoch:03d}.hdf5",
                              monitor='auc',
                              verbose=1,
                              mode='max',
                              period=1))

        # Set TensorBoard
        self.callbacks.append(TensorBoard(
            log_dir=self.config.log_superpath + "/{runname}-tb".format(runname=self.config.runname),
            batch_size=self.config.batch_size,
            write_grads=True, write_images=True))


    def train(self):
        print("Training...")
        print(len(self.classes))

        self.model.fit(
            {'input_w': self.x_train_wordvectors, 'input_c': self.x_train_numerical},
            {'outputs': self.y_train},
            epochs=self.config.epoch,
            batch_size=self.config.batch_size,
            class_weight='auto',
            validation_data=(
                {
                    'input_w': self.x_test_wordvectors,
                    'input_c': self.x_test_numerical
                },
                {
                    'outputs': self.y_test}
            ),
            callbacks=self.callbacks,
            shuffle=True
        )