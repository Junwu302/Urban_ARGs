import os
import keras
import json
import click
import sys
import numpy as np
from tqdm import tqdm
import logging
import pandas as pd
import tensorflow as tf
from keras import backend as K
from arg_loading import recall, auc, fasta2vec, get_wordvectors


def predict(inputfile, wordvec_model, kmer, arg_model, arg_parameters, outdir, num, prefix):
    os.system(
        'diamond blastp -d dia.dmnd -q '
        + inputfile + ' -p 100 --id 90 --subject-cover 70 -o temp_1.tsv')
    os.system('sort -k1,2 -u temp_1.tsv > temp_2.tsv')
    if os.path.getsize('temp_2.tsv') != 0:
        dia = pd.read_csv('temp_2.tsv', sep='\t', header=None)
        dia=dia[[0,1,2,3]]
        col_list = [0, 3, 1, 2]
        dia = dia[col_list]
        list_dia = dia[0].tolist()
    else:
        list_dia=[]
    os.system('rm -f temp_1.tsv')
    os.system('rm -f temp_2.tsv')


    y_train_path, seq_train_path, wv_train_path=fasta2vec(inputfile, wordvec_model, outdir, kmer, list_dia, prefix)
    wordvectors, sequences = get_wordvectors(
        sequence_file = seq_train_path,
        dataset_file = wv_train_path,
        maxlen=1200
    )
    print(wordvectors.shape)
    print(sequences.shape)
    model = keras.models.load_model(arg_model, custom_objects={'recall': recall, 'auc': auc})

    y = model.predict(
        {
            'wordvectors_input': wordvectors,
            'convolutional_input': sequences
        },
        verbose=1
    )

    metadata = json.load(open(arg_parameters))
    file_order = [
        i.strip() for i in open(y_train_path)
    ]

    fo = open(outdir + prefix + '_predictions.txt', 'w')
    fo.write("Query\tlen\tPrediction\tProbability\n")
    for ip, probabilities in tqdm(enumerate(y)):
        query = file_order[ip]
        for ix in range(-1, -1-num, -1):
            best_probabilities = np.sort(probabilities)[ix]
            position = np.argsort(probabilities)[ix]
            fo.write('\t'.join([query, metadata["reverse_classes_dict"][str(position)], str(best_probabilities)]) + '\n')

    fo.close()

