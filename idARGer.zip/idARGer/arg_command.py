import argparse
import configparser
import os
from arg_predict import predict
from arg_train import RCNet, NetConfig

def main():
    parse()

def parse():
    parser = argparse.ArgumentParser(prog='idarg', description="Identify antibiotic resistance gene (ARGs)")
    parser.add_argument('-v', '--version', dest='version', action='store_true', help='Print version.')
    subparsers = parser.add_subparsers(help='idarg subcommands. See command --help for details.', dest='subparser')

    # create the parser for the "predict" command
    parser_predict = subparsers.add_parser('predict', help='Predict using a trained model.')
    parser_predict.add_argument('-i', '--input', help="Input file path [.fasta].")
    parser_predict.add_argument('-o', '--output', help="Output file path [.txt].")
    parser_predict.add_argument('-p', '--prefix', dest="prefix", help="prefix", default="prefix")

    parser_predict.add_argument('-n', '--num', dest="num", help="Top num results", default=1, type=int)
    parser_predict.add_argument('-wm', '--wv-modle', dest="wordvec_model", help="wordvec_model")
    parser_predict.add_argument('-k', '--kmer', dest="kmer", help="kmer", default=11, type=int)
    parser_predict.add_argument('-am', '--arg-model', dest="arg_model", help="arg_model")
    parser_predict.add_argument('-ap', '--arg-para', dest="arg_parameters", help="arg_parameters")
    parser_predict.set_defaults(func=run_predict)

    # create the parser for the "filter" command

    # create the parser for the "train" command
    parser_train = subparsers.add_parser('train', help='Train a new model.')
    parser_train.add_argument('-g', '--n-gpus', dest="n_gpus", help="Number of GPUs.", default=0, type=int)
    parser_train.add_argument('-p', '--prefix', dest="prefix", help="prefix", default="prefix")
    parser_train.add_argument('-wm', '--wv-modle', dest="wordvec_model", help="wordvec_model")
    parser_train.add_argument('-a', '--all-data', dest="all_data", help="Path to all data.")
    parser_train.add_argument('-T', '--train-data', dest="train_data", help="Path to training data.")
    parser_train.add_argument('-t', '--test-data', dest="test_data", help="Path to test data.")
    parser_train.add_argument('-o', '--output', help="Output file dir")
    parser_train.set_defaults(func=run_train)

    args = parser.parse_args()

    if args.version:
        print('1.0')
    elif hasattr(args, 'func'):
        args.func(args)
    else:
        print('1.0')
        parser.print_help()


def run_train(args):
    config_path = os.path.join(os.path.dirname(__file__), "config", "train.ini")
    config = configparser.ConfigParser()
    config.read(config_path)
    paprconfig = NetConfig(config)

    if args.prefix:
        paprconfig.runname = args.prefix
    if args.wordvec_model:
        paprconfig.wv_model_path = args.wordvec_model
    else:
        paprconfig.wv_model_path = os.path.join(os.path.dirname(__file__), "model", "wv_model.bin")

    if args.all_data:
        paprconfig.header_path = args.all_data
    if args.train_data:
        paprconfig.train_path = args.train_data
    if args.test_data:
        paprconfig.test_path = args.test_data
    if args.n_gpus:
        paprconfig.n_gpus = args.n_gpus
    if args.output:
        paprconfig.out_path = args.output
    else:
        paprconfig.out_path = os.path.join(os.path.dirname(__file__))

    paprnet = RCNet(paprconfig)
    paprnet.load_data()
    paprnet.build_model()
    paprnet.compile_model()
    paprnet.train()


def run_predict(args):
    if args.output is None:
        args.output = os.path.join(os.path.dirname(__file__))
    if args.wordvec_model:
        wv_model_path = args.wordvec_model
    else:
        wv_model_path = os.path.join(os.path.dirname(__file__), "model", "wv_model.bin")
    if args.arg_model:
        model_path = args.arg_model
    else:
        model_path = os.path.join(os.path.dirname(__file__), "model", "model.hdf5")
    if args.arg_parameters:
        parameters_path = args.arg_parameters
    else:
        parameters_path = os.path.join(os.path.dirname(__file__), "model", "model.parameters.json")

    predict(args.input, wv_model_path, args.kmer, model_path, parameters_path, args.output, args.num, args.prefix)


if __name__ == "__main__":
    main()
