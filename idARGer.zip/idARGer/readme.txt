安装 diamond 并添加环境变量 
pip install fasttext==0.8.3
pip install tensorflow==1.13.1

Usage:
basic:
python arg_command.py predict -i predict_data.fasta
python arg_command.py train -T train_data.fasta -t test_data.fasta -a all_data.fasta
advanced:
edit ./config/train.ini
